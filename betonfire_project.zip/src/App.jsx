import { useState } from "react";

export default function App() {
  const [value, setValue] = useState(0);
  const [user, setUser] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);
  const [bets, setBets] = useState([]);
  const [amount, setAmount] = useState("");

  const handleLogin = () => {
    if (user) setLoggedIn(true);
  };

  const handleDeposit = () => {
    const val = parseFloat(amount);
    if (!isNaN(val)) {
      setValue(value + val);
      setAmount("");
      alert("Depósito de R$ " + val.toFixed(2) + " realizado com sucesso!");
    }
  };

  const placeBet = (match) => {
    const betAmount = 10;
    if (value >= betAmount) {
      setValue(value - betAmount);
      setBets([...bets, match]);
      alert("Aposta de R$ 10,00 feita em " + match);
    } else {
      alert("Saldo insuficiente");
    }
  };

  if (!loggedIn) {
    return (
      <div
        style={{
          minHeight: "100vh",
          backgroundColor: "#000000",
          color: "#fff",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: "1rem",
        }}
      >
        <h1
          style={{
            fontSize: "2.5rem",
            fontWeight: "bold",
            marginBottom: "1rem",
            color: "#FF6700",
          }}
        >
          BetOnFire 🔥
        </h1>
        <div
          style={{
            backgroundColor: "#121212",
            padding: "1rem",
            borderRadius: "8px",
            width: "100%",
            maxWidth: "400px",
          }}
        >
          <h2 style={{ fontSize: "1.25rem", marginBottom: "1rem" }}>Login</h2>
          <input
            type="text"
            placeholder="Digite seu nome de usuário"
            value={user}
            onChange={(e) => setUser(e.target.value)}
            style={{
              width: "100%",
              padding: "0.5rem",
              marginBottom: "1rem",
              borderRadius: "4px",
              border: "1px solid #FF6700",
              backgroundColor: "#000",
              color: "#fff",
              fontSize: "1rem",
            }}
          />
          <button
            onClick={handleLogin}
            style={{
              width: "100%",
              padding: "0.75rem",
              backgroundColor: "#FF6700",
              border: "none",
              borderRadius: "4px",
              fontWeight: "bold",
              color: "#000",
              cursor: "pointer",
              fontSize: "1rem",
            }}
          >
            Entrar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        backgroundColor: "#000",
        color: "#fff",
        padding: "1rem",
        fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      }}
    >
      <header
        style={{
          textAlign: "center",
          fontSize: "2rem",
          fontWeight: "bold",
          marginBottom: "1.5rem",
          color: "#FF6700",
        }}
      >
        BetOnFire 🔥 - Bem-vindo, {user}
      </header>

      <main
        style={{
          display: "grid",
          gridTemplateColumns: "1fr",
          gap: "1rem",
          maxWidth: "960px",
          margin: "0 auto",
        }}
      >
        <section
          style={{
            backgroundColor: "#121212",
            borderRadius: "8px",
            padding: "1rem",
          }}
        >
          <h2 style={{ fontSize: "1.5rem", marginBottom: "0.75rem" }}>
            Saldo da Conta
          </h2>
          <p style={{ fontSize: "2rem", fontWeight: "bold" }}>
            R$ {value.toFixed(2)}
          </p>
          <div style={{ marginTop: "1rem", display: "flex", gap: "0.5rem" }}>
            <input
              type="number"
              placeholder="Valor (R$)"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              style={{
                flex: "1",
                padding: "0.5rem",
                borderRadius: "4px",
                border: "1px solid #FF6700",
                backgroundColor: "#000",
                color: "#fff",
                fontSize: "1rem",
              }}
            />
            <button
              onClick={handleDeposit}
              style={{
                backgroundColor: "#28a745",
                color: "#fff",
                border: "none",
                borderRadius: "4px",
                padding: "0.5rem 1rem",
                cursor: "pointer",
                fontWeight: "bold",
              }}
            >
              Depositar Pix
            </button>
          </div>
        </section>

        <section
          style={{
            backgroundColor: "#121212",
            borderRadius: "8px",
            padding: "1rem",
          }}
        >
          <h2 style={{ fontSize: "1.5rem", marginBottom: "0.75rem" }}>
            Jogos para Apostar
          </h2>
          <ul style={{ listStyle: "none", paddingLeft: 0 }}>
            {["Flamengo x Palmeiras", "Corinthians x Santos", "Grêmio x Inter"].map(
              (match) => (
                <li
                  key={match}
                  style={{
                    marginBottom: "0.75rem",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <span>{match}</span>
                  <button
                    onClick={() => placeBet(match)}
                    style={{
                      backgroundColor: "#FF6700",
                      border: "none",
                      borderRadius: "4px",
                      color: "#000",
                      fontWeight: "bold",
                      cursor: "pointer",
                      padding: "0.3rem 0.8rem",
                    }}
                  >
                    Apostar R$10
                  </button>
                </li>
              )
            )}
          </ul>
        </section>

        <section
          style={{
            backgroundColor: "#121212",
            borderRadius: "8px",
            padding: "1rem",
          }}
        >
          <h2 style={{ fontSize: "1.5rem", marginBottom: "0.75rem" }}>
            Minhas Apostas
          </h2>
          {bets.length === 0 ? (
            <p>Nenhuma aposta realizada.</p>
          ) : (
            <ul style={{ paddingLeft: "1.25rem" }}>
              {bets.map((bet, i) => (
                <li key={i} style={{ marginBottom: "0.5rem" }}>
                  {bet}
                </li>
              ))}
            </ul>
          )}
        </section>
      </main>

      <footer
        style={{
          textAlign: "center",
          marginTop: "2rem",
          fontSize: "0.875rem",
          color: "#666",
        }}
      >
        © 2025 BetOnFire. Todos os direitos reservados.
      </footer>
    </div>
  );
}